package com.sp.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.sp.dto.StudentDTO;
import com.sp.service.SpService;

@RestController
@RequestMapping("/stud")
public class SpController {
	
    @Autowired
    SpService spService;
	
    @GetMapping("/list")
    public List<StudentDTO> getStudList(){
    	return spService.getstudentList();
    }
    @GetMapping("/list-filtered-by-dep")
    public Map<String, List<StudentDTO>> getStudListFilteredByDep(){
    	return spService.getStudListFilteredByDep();
    }
    @GetMapping("/list-filtered-by-dept")
    public Map<String, Object> getStudListFilteredByDept(){
    	return spService.getStudListFilteredByDept();
    }
    @GetMapping("/get-stud-details")
	public Map<String, StudentDTO> getStudDetails() {
		return spService.getStudDetails();
	}
    @GetMapping("/list-filtered-by-depart")
	public Map<String, StudentDTO> getStudListFilteredByDepart() {
		return spService.getStudListFilteredByDepart();
	}
}
