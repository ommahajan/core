package com.sp.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.sp.dto.CourseDTO;
import com.sp.dto.StudentDTO;

@Service
public class SpService {
	
    public List<StudentDTO> getstudentList(){
    	
    	List<StudentDTO> studList = new ArrayList<>();
    	Random random = new Random();  
    	
    	for(int i = 1; i <= 20; i++) {
    		
    		if(i <=5) {
    			StudentDTO studentDTO = new StudentDTO();
    	    	studentDTO.setId(random.nextInt(50));
    	    	studentDTO.setName("Om-" + i);
    	    	studentDTO.setDept("CSE");
    	    	studList.add(studentDTO);
    		}else if(i > 5 && i <= 12) {
    			StudentDTO studentDTO = new StudentDTO();
    	    	studentDTO.setId(random.nextInt(50));
    	    	studentDTO.setName("Om-" + i);
    	    	studentDTO.setDept("IT");
    	    	studList.add(studentDTO);
    		}else {
    			StudentDTO studentDTO = new StudentDTO();
    	    	studentDTO.setId(random.nextInt(50));
    	    	studentDTO.setName("Om-" + i);
    	    	studentDTO.setDept("CIVIL");
    	    	studList.add(studentDTO);
    		}
    		
    	}
    	
    	return studList;
    }
    
	public Map<String, List<StudentDTO>> getStudListFilteredByDep() {

//		Map<String, List<StudentDTO>> studMap = new LinkedHashMap<>(); // maintained the insertion order
		Map<String, List<StudentDTO>> studMap = new HashMap<>();
		List<StudentDTO> studList = this.getstudentList();
		/** Type-1 : sort list in ascending order
		List<StudentDTO> studList = this.getstudentList().stream()
		.sorted(Comparator.comparing(StudentDTO::getId).thenComparing(StudentDTO::getName))
		.collect(Collectors.toList()); */
		for(StudentDTO s : studList) {
			StudentDTO stud = new StudentDTO();
			BeanUtils.copyProperties(s, stud);
			if(studMap.containsKey(stud.getDept())) {
				List<StudentDTO> studListByKey = studMap.get(stud.getDept());
				studListByKey.add(stud);
			}else {
				List<StudentDTO> studListByKey = new ArrayList<>();
				studListByKey.add(stud);
				studMap.put(stud.getDept(), studListByKey);
			}
		}
		/** Type-2 : sort list in ascending order
		if (studMap.containsKey("CIVIL")) {
			List<StudentDTO> civilStudList = studMap.get("CIVIL").stream().sorted(Comparator.comparing(StudentDTO::getId)).collect(Collectors.toList());
			studMap.get("CIVIL").clear();
			studMap.put("CIVIL", civilStudList);			
		}
		if (studMap.containsKey("CSE")) {
			List<StudentDTO> cseStudList = studMap.get("CSE").stream().sorted(Comparator.comparing(StudentDTO::getId)).collect(Collectors.toList());
			studMap.get("CSE").clear();
			studMap.put("CSE", cseStudList);
		}
		if (studMap.containsKey("IT")) {
			List<StudentDTO> itStudList = studMap.get("IT").stream().sorted(Comparator.comparing(StudentDTO::getId)).collect(Collectors.toList());
			studMap.get("IT").clear();
			studMap.put("IT", itStudList);
		} */
		/** Type-3 : sort list in ascending order
		for (Map.Entry<String, List<StudentDTO>> studMapEntry : studMap.entrySet()) {
			List<StudentDTO> sortedStudList= studMapEntry.getValue().stream().sorted(Comparator.comparing(StudentDTO::getId)).collect(Collectors.toList());
			studMapEntry.getValue().clear();
			studMapEntry.getValue().addAll(sortedStudList);
		} */
		return studMap;
	}
	
	@SuppressWarnings("unchecked")
	public Map<String, Object> getStudListFilteredByDept() {

//		Map<String, List<StudentDTO>> studMap = new LinkedHashMap<>(); // maintained the insertion order
		Map<String, Object> studMap = new HashMap<>();
		List<StudentDTO> studList = this.getstudentList();
		/** sort list in ascending order
		List<StudentDTO> studList = this.getstudentList().stream()
		.sorted(Comparator.comparing(StudentDTO::getId).thenComparing(StudentDTO::getName))
		.collect(Collectors.toList()); */
		for(StudentDTO s : studList) {
			StudentDTO stud = new StudentDTO();
			BeanUtils.copyProperties(s, stud);
			if(studMap.containsKey(stud.getDept())) {
				List<StudentDTO> studListByKey = (List<StudentDTO>) studMap.get(stud.getDept());
				studListByKey.add(stud);
			}else {
				List<StudentDTO> studListByKey = new ArrayList<>();
				studListByKey.add(stud);
				studMap.put(stud.getDept(), studListByKey);
			}
		}
		/** sort list in ascending order
		for (Map.Entry<String, Object> studMapEntry : studMap.entrySet()) {
			List<StudentDTO> studListByKey = ((List<StudentDTO>) studMapEntry.getValue()).stream().sorted(Comparator.comparing(StudentDTO::getId)).collect(Collectors.toList());
			((List<StudentDTO>) studMapEntry.getValue()).clear();
			((List<StudentDTO>) studMapEntry.getValue()).addAll(studListByKey);
		} */
		/** sort list in ascending order -- Not Tested
		for (Map.Entry<String, Object> studMapEntry : studMap.entrySet()) {
			for(StudentDTO studentDTO :((List<StudentDTO>) studMapEntry.getValue())) {
			List<CourseDTO> courseList = studentDTO.getCourseList().stream().sorted(Comparator.comparing(CourseDTO::getName)).collect(Collectors.toList());
			((StudentDTO) studMapEntry.getValue()).getCourseList().clear();
			((StudentDTO) studMapEntry.getValue()).getCourseList().addAll(courseList);
			}
		} */
		studMap.put("message", "Student List Delivered Successfully..!!");
		studMap.put("status", true);
		return studMap;
	}
	
	public Map<String, StudentDTO> getStudDetails() {
		Map<String, StudentDTO> studMap = new HashMap<>();
		StudentDTO studentDTO = new StudentDTO();
    	studentDTO.setId(101);
    	studentDTO.setName("Om");
    	studentDTO.setDept("CSE");
    	studentDTO.setCourseList(new ArrayList<>());
    	studMap.put("Stud",studentDTO);
    	/** sort list in ascending order -- Not Tested
    	for (Map.Entry<String, StudentDTO> studMapEntry : studMap.entrySet()) {
    		List<CourseDTO> courseList = studMapEntry.getValue().getCourseList().stream().sorted(Comparator.comparing(CourseDTO::getName)).collect(Collectors.toList());
    		studMapEntry.getValue().getCourseList().clear();
    		studMapEntry.getValue().getCourseList().addAll(courseList);
    	} */
		return studMap;
	}
	
	public Map<String, StudentDTO> getStudListFilteredByDepart() {
		Map<String, StudentDTO> studMap = new HashMap<>();
		List<StudentDTO> studList = this.getstudentList();
		for(StudentDTO stud : studList) {
			String dept = stud.getDept();
			if(studMap.get(dept) == null) {
				StudentDTO studentDTO = new StudentDTO();
		    	studentDTO.setDept(dept);
		    	studMap.put(dept, studentDTO);
			}
			
			StudentDTO studentDTO = new StudentDTO();
	    	studentDTO.setId(stud.getId());
	    	studentDTO.setName(stud.getName());
	    	
	    	if(studMap.get(dept) != null) {
	    		studMap.get(dept).getStudentList().add(studentDTO);
	    	}
		}
		return studMap;
	}

}
