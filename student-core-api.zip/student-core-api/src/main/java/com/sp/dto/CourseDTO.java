package com.sp.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(content = Include.NON_EMPTY, value = Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CourseDTO {
	
	private Integer id;
	private Integer name;

}
