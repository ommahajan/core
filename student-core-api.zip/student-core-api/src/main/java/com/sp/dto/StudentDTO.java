package com.sp.dto;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(content = Include.NON_EMPTY, value = Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class StudentDTO {
	
	private Integer id;
	private String name;
	private String dept;
    List<CourseDTO> courseList =  new ArrayList<CourseDTO>();
    List<StudentDTO> studentList =  new ArrayList<StudentDTO>();

}
